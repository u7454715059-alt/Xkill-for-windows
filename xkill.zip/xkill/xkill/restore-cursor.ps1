Add-Type -Namespace Native -Name Cur -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SystemParametersInfo(uint a, uint b, System.IntPtr c, uint d);
'@
[Native.Cur]::SystemParametersInfo(0x57, 0, [System.IntPtr]::Zero, 0) | Out-Null
