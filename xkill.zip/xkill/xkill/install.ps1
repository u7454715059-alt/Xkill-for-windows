$dest = Join-Path $env:LOCALAPPDATA "Programs\xkill"
New-Item -ItemType Directory -Force -Path $dest | Out-Null

Get-ChildItem -Path $PSScriptRoot -File | Where-Object {
    $_.Name -like "xkill.*" -or $_.Name -like "restore-cursor.*" -or $_.Name -eq "cur" -or $_.Name -like "cur.*" -or
    $_.Extension -in ".cur", ".ani", ".png"
} | ForEach-Object {
    Copy-Item $_.FullName -Destination $dest -Force
}
Get-ChildItem -Path $dest -File | Unblock-File

$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if (-not $userPath) { $userPath = "" }
if (($userPath -split ';') -notcontains $dest) {
    $new = ($userPath.TrimEnd(';') + ";" + $dest).TrimStart(';')
    [Environment]::SetEnvironmentVariable("Path", $new, "User")
}

Write-Host "xkill installed. Open a NEW terminal, then run: sudo xkill"
