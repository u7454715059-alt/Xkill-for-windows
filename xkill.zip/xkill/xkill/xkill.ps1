param(
    [Alias("Png", "Path")]
    [string]$Cursor = "",
    [int]$Size = 32
)

if (-not $Cursor) {
    foreach ($name in "xkill.cur", "xkill.ani", "xkill.png", "cur.cur", "cur.ani", "cur.png", "cur") {
        $candidate = Join-Path $PSScriptRoot $name
        if (Test-Path $candidate -PathType Leaf) { $Cursor = $candidate; break }
    }
    if (-not $Cursor) {
        $any = Get-ChildItem -Path $PSScriptRoot -File | Where-Object { $_.Extension -in ".cur", ".ani" } | Select-Object -First 1
        if ($any) { $Cursor = $any.FullName }
    }
}

$code = @'
using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;

public static class XKill
{
    const int WH_KEYBOARD_LL = 13, WH_MOUSE_LL = 14;
    const int WM_KEYDOWN = 0x100;
    const int WM_LBUTTONDOWN = 0x201, WM_LBUTTONUP = 0x202;
    const int WM_RBUTTONDOWN = 0x204, WM_RBUTTONUP = 0x205;
    const int VK_ESCAPE = 0x1B;
    const uint GA_ROOT = 2;
    const uint SPI_SETCURSORS = 0x57;
    const uint WM_QUIT = 0x12;

    static readonly uint[] CursorIds = {
        32512, 32513, 32514, 32515, 32516, 32642, 32643,
        32644, 32645, 32646, 32648, 32649, 32650
    };

    [StructLayout(LayoutKind.Sequential)] struct POINT { public int x, y; }
    [StructLayout(LayoutKind.Sequential)] struct MSLLHOOKSTRUCT { public POINT pt; public uint mouseData, flags, time; public IntPtr extra; }
    [StructLayout(LayoutKind.Sequential)] struct KBDLLHOOKSTRUCT { public uint vkCode, scanCode, flags, time; public IntPtr extra; }
    [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam, lParam; public uint time; public POINT pt; }
    [StructLayout(LayoutKind.Sequential)] struct ICONINFO { public bool fIcon; public int xHotspot, yHotspot; public IntPtr hbmMask, hbmColor; }

    delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);
    delegate bool EnumProc(IntPtr hwnd, IntPtr lParam);
    delegate bool ConsoleCtrlDelegate(uint type);

    [DllImport("user32.dll")] static extern IntPtr SetWindowsHookEx(int id, HookProc fn, IntPtr mod, uint tid);
    [DllImport("user32.dll")] static extern bool UnhookWindowsHookEx(IntPtr h);
    [DllImport("user32.dll")] static extern IntPtr CallNextHookEx(IntPtr h, int n, IntPtr w, IntPtr l);
    [DllImport("kernel32.dll")] static extern IntPtr GetModuleHandle(string name);
    [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
    [DllImport("kernel32.dll")] static extern bool SetConsoleCtrlHandler(ConsoleCtrlDelegate handler, bool add);
    [DllImport("user32.dll")] static extern int GetMessage(out MSG m, IntPtr hwnd, uint min, uint max);
    [DllImport("user32.dll")] static extern bool PostThreadMessage(uint tid, uint msg, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] static extern void PostQuitMessage(int code);
    [DllImport("user32.dll")] static extern IntPtr WindowFromPoint(POINT p);
    [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr hwnd, System.Text.StringBuilder sb, int max);
    [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent, EnumProc fn, IntPtr lParam);
    [DllImport("user32.dll")] static extern bool SetSystemCursor(IntPtr hcur, uint id);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr LoadCursorFromFile(string path);
    [DllImport("user32.dll")] static extern IntPtr CopyIcon(IntPtr h);
    [DllImport("user32.dll")] static extern bool DestroyIcon(IntPtr h);
    [DllImport("user32.dll")] static extern bool GetIconInfo(IntPtr hIcon, out ICONINFO info);
    [DllImport("user32.dll")] static extern IntPtr CreateIconIndirect(ref ICONINFO info);
    [DllImport("user32.dll")] static extern bool SystemParametersInfo(uint action, uint param, IntPtr vparam, uint winIni);
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);

    static ConsoleCtrlDelegate ctrlHandler = CtrlCb;
    static HookProc mouseProc = MouseCb;
    static HookProc kbProc = KbCb;
    static IntPtr mouseHook = IntPtr.Zero, kbHook = IntPtr.Zero;
    static uint mainThread;
    static bool fuckoff = false;

    static bool CtrlCb(uint type)
    {
        if (type == 2 || type == 5 || type == 6) RestoreCursors();
        return false;
    }

    static Bitmap Fallback(int size)
    {
        Bitmap b = new Bitmap(size, size);
        using (Graphics g = Graphics.FromImage(b))
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using (Pen p = new Pen(Color.Black, size / 5f)) { g.DrawLine(p, 3, 3, size - 4, size - 4); g.DrawLine(p, size - 4, 3, 3, size - 4); }
            using (Pen p = new Pen(Color.Red, size / 8f)) { g.DrawLine(p, 3, 3, size - 4, size - 4); g.DrawLine(p, size - 4, 3, 3, size - 4); }
        }
        return b;
    }

    static IntPtr MakeCursor(string path, int size)
    {
        Bitmap bmp;
        try
        {
            using (Bitmap src = new Bitmap(path)) { bmp = new Bitmap(src, new Size(size, size)); }
        }
        catch
        {
            bmp = Fallback(size);
        }
        IntPtr hIcon = bmp.GetHicon();
        ICONINFO ii;
        GetIconInfo(hIcon, out ii);
        ii.fIcon = false;
        ii.xHotspot = size / 2;
        ii.yHotspot = size / 2;
        IntPtr cur = CreateIconIndirect(ref ii);
        DestroyIcon(hIcon);
        DeleteObject(ii.hbmMask);
        DeleteObject(ii.hbmColor);
        bmp.Dispose();
        return cur;
    }

    static void RestoreCursors()
    {
        SystemParametersInfo(SPI_SETCURSORS, 0, IntPtr.Zero, 0);
    }

    static string ClassOf(IntPtr h)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder(256);
        GetClassName(h, sb, 256);
        return sb.ToString();
    }

    static void KillAt(POINT pt)
    {
        IntPtr h = WindowFromPoint(pt);
        if (h == IntPtr.Zero) return;
        IntPtr root = GetAncestor(h, GA_ROOT);
        if (root == IntPtr.Zero) root = h;

        string cls = ClassOf(root);
        if (cls == "Progman" || cls == "WorkerW" || cls == "Shell_TrayWnd" || cls == "Shell_SecondaryTrayWnd") return;

        uint pid;
        GetWindowThreadProcessId(root, out pid);

        if (cls == "ApplicationFrameWindow")
        {
            uint hostPid = pid;
            uint realPid = 0;
            EnumChildWindows(root, delegate(IntPtr child, IntPtr lp)
            {
                uint cp;
                GetWindowThreadProcessId(child, out cp);
                if (cp != hostPid && cp != 0) { realPid = cp; return false; }
                return true;
            }, IntPtr.Zero);
            if (realPid != 0) pid = realPid;
        }

        if (pid == (uint)Process.GetCurrentProcess().Id) return;

        try
        {
            Process.GetProcessById((int)pid).Kill();
        }
        catch { }
    }

    static IntPtr MouseCb(int n, IntPtr w, IntPtr l)
    {
        if (n >= 0)
        {
            int m = (int)w;
            if (m == WM_LBUTTONDOWN)
            {
                MSLLHOOKSTRUCT s = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(l, typeof(MSLLHOOKSTRUCT));
                fuckoff = true;
                RestoreCursors();
                KillAt(s.pt);
                return (IntPtr)1;
            }
            if (m == WM_RBUTTONDOWN)
            {
                fuckoff = true;
                return (IntPtr)1;
            }
            if (m == WM_LBUTTONUP || m == WM_RBUTTONUP)
            {
                if (fuckoff) PostQuitMessage(0);
                return (IntPtr)1;
            }
        }
        return CallNextHookEx(mouseHook, n, w, l);
    }

    static IntPtr KbCb(int n, IntPtr w, IntPtr l)
    {
        if (n >= 0 && (int)w == WM_KEYDOWN)
        {
            KBDLLHOOKSTRUCT k = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(l, typeof(KBDLLHOOKSTRUCT));
            if (k.vkCode == VK_ESCAPE)
            {
                PostQuitMessage(0);
                return (IntPtr)1;
            }
        }
        return CallNextHookEx(kbHook, n, w, l);
    }

    public static void Run(string path, int size)
    {
        SetProcessDPIAware();
        mainThread = GetCurrentThreadId();

        ConsoleCancelEventHandler onCancel = delegate(object s, ConsoleCancelEventArgs e)
        {
            e.Cancel = true;
            PostThreadMessage(mainThread, WM_QUIT, IntPtr.Zero, IntPtr.Zero);
        };
        Console.CancelKeyPress += onCancel;
        SetConsoleCtrlHandler(ctrlHandler, true);

        bool native = false;
        if (!string.IsNullOrEmpty(path))
        {
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            native = ext != ".png" && System.IO.File.Exists(path);
        }

        IntPtr cur = IntPtr.Zero;
        if (!native) cur = MakeCursor(path, size);
        try
        {
            foreach (uint id in CursorIds)
            {
                IntPtr h = native ? LoadCursorFromFile(path) : CopyIcon(cur);
                if (h == IntPtr.Zero) break;
                SetSystemCursor(h, id);
            }
            if (cur != IntPtr.Zero) DestroyIcon(cur);

            IntPtr mod = GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName);
            mouseHook = SetWindowsHookEx(WH_MOUSE_LL, mouseProc, mod, 0);
            kbHook = SetWindowsHookEx(WH_KEYBOARD_LL, kbProc, mod, 0);

            MSG msg;
            while (GetMessage(out msg, IntPtr.Zero, 0, 0) > 0) { }
        }
        finally
        {
            if (mouseHook != IntPtr.Zero) UnhookWindowsHookEx(mouseHook);
            if (kbHook != IntPtr.Zero) UnhookWindowsHookEx(kbHook);
            RestoreCursors();
            Console.CancelKeyPress -= onCancel;
        }
    }
}
'@

Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition $code -Language CSharp

[XKill]::Run($Cursor, $Size)
