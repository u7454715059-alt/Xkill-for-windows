@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore-cursor.ps1"
