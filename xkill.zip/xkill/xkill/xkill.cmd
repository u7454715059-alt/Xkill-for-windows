@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0xkill.ps1" %*
