$dest = Join-Path $env:LOCALAPPDATA "Programs\xkill"
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath) {
    $new = (($userPath -split ';') | Where-Object { $_ -and $_ -ne $dest }) -join ';'
    [Environment]::SetEnvironmentVariable("Path", $new, "User")
}
if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
Write-Host "xkill removed."
